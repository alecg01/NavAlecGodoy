package com.example.navalecgodoy

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.navigation.Navigation
import com.example.navalecgodoy.databinding.FragmentLoginBinding

class LoginFragment: Fragment() {
    private lateinit var binding: FragmentLoginBinding
    var usuario: String = "UCA"
    var contrasena:String = "Nicaragua"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {  }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentLoginBinding.inflate(layoutInflater)
        inicioSesion()
        return binding.root
    }

    private fun inicioSesion() {

        binding.btnEntrar.setOnClickListener {
            val nameTemp:String = binding.etUsuario.text.toString()
            val pwdTemp:String = binding.etContrasena.text.toString()

            if(nameTemp == usuario && pwdTemp == contrasena){
                Navigation.findNavController(binding.root).navigate(R.id.menuFragment)
            }
        }

    }

}