package com.example.navalecgodoy

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.example.navalecgodoy.databinding.FragmentAntecesorBinding
import com.example.navalecgodoy.databinding.FragmentConvertirBinding

class AntecesorFragment: Fragment() {
    private lateinit var binding: FragmentAntecesorBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {  }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentAntecesorBinding.inflate(layoutInflater)
        return binding.root
    }
}